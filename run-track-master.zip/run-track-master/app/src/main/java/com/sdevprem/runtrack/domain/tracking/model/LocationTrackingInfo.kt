package com.sdevprem.runtrack.domain.tracking.model

data class LocationTrackingInfo(
    val locationInfo: LocationInfo,
    val speedInMS: Float,
)
