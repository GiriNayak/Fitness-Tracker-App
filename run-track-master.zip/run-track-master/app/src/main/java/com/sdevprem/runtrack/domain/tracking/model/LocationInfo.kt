package com.sdevprem.runtrack.domain.tracking.model

data class LocationInfo(
    val latitude: Double,
    val longitude: Double
)
