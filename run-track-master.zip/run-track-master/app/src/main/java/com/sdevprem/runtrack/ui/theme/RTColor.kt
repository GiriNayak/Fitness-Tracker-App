package com.sdevprem.runtrack.ui.theme

import androidx.compose.ui.graphics.Color

object RTColor {
    //custom colors
    val CHATEAU_GREEN = Color(0xFF33A853)
}