package com.sdevprem.runtrack.data.model

enum class Gender {
    MALE, FEMALE
}