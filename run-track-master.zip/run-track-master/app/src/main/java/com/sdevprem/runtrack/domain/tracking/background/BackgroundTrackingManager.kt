package com.sdevprem.runtrack.domain.tracking.background

interface BackgroundTrackingManager {
    fun startBackgroundTracking()
    fun stopBackgroundTracking()
}