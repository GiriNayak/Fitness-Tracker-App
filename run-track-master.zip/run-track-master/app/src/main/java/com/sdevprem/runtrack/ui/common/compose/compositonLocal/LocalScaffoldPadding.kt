package com.sdevprem.runtrack.ui.common.compose.compositonLocal

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.unit.dp

val LocalScaffoldBottomPadding = compositionLocalOf { 0.dp }