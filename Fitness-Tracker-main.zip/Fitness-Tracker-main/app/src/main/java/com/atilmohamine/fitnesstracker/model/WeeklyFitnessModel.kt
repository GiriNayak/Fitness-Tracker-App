package com.atilmohamine.fitnesstracker.model

data class WeeklyFitnessModel(
    val dailyFitnessList: List<DailyFitnessModel>
)